//------------------------------------------------------------------------------------------------------------------//
//Header files
#include <windows.h> //This is for windows.
#include"accessories.h"//Header file which declares and defines necessary structs,classes etc
using namespace std;
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//Macros
#define TITLE "animating Circle" //macro for glut console application title.
#define BUFSIZE 512 //selectBuf size
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//Global Variables
GLint window_width, window_height;
char title[] = TITLE;
GLint vp[4];
screen glutScreen;
buttonCube* buttonCube::instanceCube = NULL;
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//User defined function declarations
void processHits(GLint hits, GLuint buffer[]);
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This application Initialisations definitions
void initGL()
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);//Color buffers are cleared and initialise screen to black.
	glClearDepth(1.0f);//initialise depth value to 1.
	glEnable(GL_DEPTH_TEST);//Enable depth test so that depth test failed fragments can be discarded
	glDepthFunc(GL_LEQUAL);//Depth test will Passes if the incoming depth value is equal to the stored depth value.
	glShadeModel(GL_SMOOTH);//To enable smooth shading
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	window_width = 500; //initialisation of window width
	window_height = 500;//initialisation of window height

}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This callback will trigger once the displaying window is reshaped and adjust the screen accordingly
void reshape(GLsizei width, GLsizei height) {

	if (height == 0) height = 1;
	GLfloat aspect = (GLfloat)width / (GLfloat)height;
	window_width = width;
	window_height = height;
	glViewport(0, 0, width, height);
	glGetIntegerv(GL_VIEWPORT, vp);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, aspect, 0.1f, 100.0f);
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This method renders the User interface once glut requist for display or GL_SELECT
void myRender(GLenum mode)
{
	//renders containing circle in the list using below logic
	for (auto i = glutScreen.myCircleList.begin(); i != glutScreen.myCircleList.end(); i++)
	{
		glutScreen.renderCirclesOntheScreen(i->x1_circle, i->y1_circle);
	}
	glutScreen.renderbuttonCubeOntheScreen();
	glutScreen.renderLineOntheScreen();
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//callback function get called whenever related updates required.
void display()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	GLfloat aspect = (GLfloat)window_width / (GLfloat)window_height;
	gluPerspective(45.0f, aspect, 0.1f, 100.0f);
	glOrtho(0, 500, 500, 0, 1, 8);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(1.5f, 0.0f, 8.0f);
	myRender(GL_RENDER);
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glutSwapBuffers();
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This function handles the mouse click from cube button click.A logic is written here to process the items click for button cubes only.
//This is done using making use of glRenderMode = GL_SELECT
void mouse(int button, int state, int x, int y) {
	GLuint selectBuf[BUFSIZE];
	GLint hits = -1;
	GLint viewport[4];
	if ((button == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN))
	{
		glGetIntegerv(GL_VIEWPORT, viewport);
		glSelectBuffer(BUFSIZE, selectBuf);
		glRenderMode(GL_SELECT);
		glInitNames();
		glPushName(1);
		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		glLoadIdentity();
		gluPickMatrix((GLdouble)x, (GLdouble)(viewport[3] - y), 5.0, 5.0, viewport);
		GLfloat aspect = (GLfloat)window_width / (GLfloat)window_height;
		gluPerspective(45.0f, aspect, 0.1f, 100.0f);
		glOrtho(0, 500, 500, 0, 1, 8);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatef(1.5f, 0.0f, 8.0f);
		myRender(GL_SELECT);
		glMatrixMode(GL_PROJECTION);
		glPopMatrix();
		hits = glRenderMode(GL_RENDER);
		processHits(hits, selectBuf);
		glutPostRedisplay();
	}
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This will add circles if right arrow button pressed and delete circles if left arrow button pressed
void keyPressed(int key, int x, int y)
{
	GLuint names;
	if (key == GLUT_KEY_RIGHT)
	{
		names = 1;
		glutScreen.clickActionForMouseAndKeyboard(names);
	}
	else if (key == GLUT_KEY_LEFT)
	{
		names = 2;
		glutScreen.clickActionForMouseAndKeyboard(names);
	}

}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This method will process the mouse clicks based on the name value given during glRenderMode == GL_SELECT
void processHits(GLint hits, GLuint buffer[])
{
	GLuint names, *ptr;
	ptr = (GLuint *)buffer;
	ptr++;
	ptr++;
	ptr++;
	names = *ptr;
	glutScreen.clickActionForMouseAndKeyboard(names);
	glutPostRedisplay();
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This callback responsible for updating the circle positions based on 60 millisecond timer and gives a translation animation effect
//If the leading circles reached the end of a traversing square(say traversing is in x-direction)then it will immediatly change the travesring co-ordinate
//(say travesring direction changes to x-direction to y immediately).
void update(int value)
{
	glutScreen.translate(10);

	if (glutScreen.myCircleList.size() > 0)
	{
		glutScreen.tempCircleV = glutScreen.myCircleList.back();

		if (glutScreen.tempCircleV.traversing_count == UPPLEFTRIGHT)
		{
			if (glutScreen.tempCircleV.x1_circle + 2 * RADIUS > OrthoMAX)
			{
				for (int i = 0; i < 8; i++)
				{
					glutScreen.translate(10);
				}
			}
		}
		else if (glutScreen.tempCircleV.traversing_count == SIDETOPBOTTOM)
		{
			if (glutScreen.tempCircleV.y1_circle + 2 * RADIUS > OrthoMAX)
			{
				for (int i = 0; i < 8; i++)
				{
					glutScreen.translate(10);
				}
			}
		}
		else if (glutScreen.tempCircleV.traversing_count == DOWNRIGHTLEFT)
		{
			if (glutScreen.tempCircleV.x1_circle - 2 * RADIUS < OrthoMIN)
			{
				for (int i = 0; i < 8; i++)
				{
					glutScreen.translate(10);
				}
			}
		}
		else if (glutScreen.tempCircleV.traversing_count == SIDEBOTTOMTOP)
		{
			if (glutScreen.tempCircleV.y1_circle - 2 * RADIUS < OrthoMIN)
			{
				for (int i = 0; i < 8; i++)
				{
					glutScreen.translate(10);
				}
			}
		}
	}
	glutPostRedisplay();
	glutTimerFunc(60, update, 0);
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//Glut Application starts
int main(int argc, char** argv)
{
	glutInit(&argc, argv); //allows OpenGLUT to initialize internal structures.       
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); //Double-buffered mode + Red, green, blue framebuffer + Depth buffering.
	glutCreateWindow(title); //Glut window is created with the given title value.          
	glutDisplayFunc(display);//Sets the display callback for the current window.callback function get called whenever related updates required.      
	glutReshapeFunc(reshape);//invoke whenever the window is reshaped.  
	glutMouseFunc(mouse);
	glutSpecialFunc(keyPressed); // Tell GLUT to use the method "keyPressed" for key presses 
	glutTimerFunc(60, update, 0);//invoke translation animation by continous render
	initGL();//This application Initialisations.        
	glutMainLoop();//synchronisation of event driven approach of GLUT. 
	return 0;
}
//------------------------------------------------------------------------------------------------------------------//
