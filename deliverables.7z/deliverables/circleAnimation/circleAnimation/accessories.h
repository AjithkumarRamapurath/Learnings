#include <cmath>//This library is added to process sin and cos while drawing circle and for mathematical calculations
#include<list>//STL list included as a container for adding circles in to the the screen
#include <glut.h> //Header file for accessing information inside glut header file.
using namespace std;
//------------------------------------------------------------------------------------------------------------------//
#define UPPYVALUE 300.00
#define DOWNYVALUE 350.00
#define RADIUS 40 //radius of the rendering circles
#define OrthoMAX 430 // glOrtho max xvalue
#define OrthoMIN 50 //glOrtho min xvalue
#define UPPLEFTRIGHT 0 //for distinguishing upper left to right traversal
#define SIDETOPBOTTOM 1 //for distinguishing side top to bottom traversal
#define DOWNRIGHTLEFT 2 //for distinguishing down right to left traversal
#define SIDEBOTTOMTOP 3 //for distinguishing side bottom to top traversal
#define MAXCIRCLES 20//this will be maximum number of circles can be added to the screen
//------------------------------------------------------------------------------------------------------------------//
//button cube struct creation for + and - buttons to include all vertices for a cube creation
struct buttonCube 
{
	float vertex11[3];
	float vertex12[3];
	float vertex13[3];
	float vertex14[3];
	float color1[3];

	float vertex21[3];
	float vertex22[3];
	float vertex23[3];
	float vertex24[3];
	float color2[3];

	float vertex31[3];
	float vertex32[3];
	float vertex33[3];
	float vertex34[3];
	float color3[3];

	float vertex41[3];
	float vertex42[3];
	float vertex43[3];
	float vertex44[3];
	float color4[3];

	float vertex51[3];
	float vertex52[3];
	float vertex53[3];
	float vertex54[3];
	float color5[3];

	float vertex61[3];
	float vertex62[3];
	float vertex63[3];
	float vertex64[3];
	float color6[3];
	void setCubeVertices(int _offset);
	void colortheCube();
	void disabletheCube();
	static buttonCube* instanceCube;
	static buttonCube* getinstance()
	{
		if (instanceCube == nullptr)
		{
			instanceCube = new buttonCube();
		}
		return instanceCube;
	}
};
//------------------------------------------------------------------------------------------------------------------//
//button cube struct creation for + and - buttons to include all vertices for a cube creation
struct circleCordinates
{
	float x1_circle;
	float y1_circle;
	float z1_circle;
	int traversing_count;
	int toggleTranslate;
	//constructor
	circleCordinates();
};

//------------------------------------------------------------------------------------------------------------------//
//screen class is responsible for rendering button and circles on to the screen
class screen
{
public :
	list<circleCordinates> myCircleList;
	circleCordinates tempCircleV;
	void renderbuttonCubeOntheScreen();
	void renderLineOntheScreen();
	void renderCirclesOntheScreen(float x1_circle, float y1_circle);
	void clickActionForMouseAndKeyboard(GLuint names);
	void translate(int translatevalue);
};