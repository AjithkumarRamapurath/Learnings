#include "stdafx.h"
#include "CppUnitTest.h"
#include "../circleAnimation/accessories.h"
using namespace std;

#define UPPLEFTRIGHT 0 //for distinguishing upper left to right traversal
#define SIDETOPBOTTOM 1 //for distinguishing side top to bottom traversal
#define DOWNRIGHTLEFT 2 //for distinguishing down right to left traversal
#define SIDEBOTTOMTOP 3 //for distinguishing side bottom to top traversal


using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		TEST_METHOD(TestMethodclickActionForMouseAndKeyboard)
		{
			//mocking input 1 for first time addition
			screen testScreen;
			testScreen.tempCircleV.x1_circle = 40;
			testScreen.tempCircleV.y1_circle = 40;
			testScreen.tempCircleV.traversing_count = UPPLEFTRIGHT;
			testScreen.clickActionForMouseAndKeyboard(1);
			Assert::IsTrue(testScreen.myCircleList.size() == 1);

			//mocking input 2 for traversing in left to right x-direction and x cordinate updating properly 
			testScreen.tempCircleV.x1_circle = 40;
			testScreen.tempCircleV.y1_circle = 40;
			testScreen.tempCircleV.traversing_count = UPPLEFTRIGHT;
			testScreen.myCircleList.push_back(testScreen.tempCircleV);
			testScreen.clickActionForMouseAndKeyboard(1);
			Assert::IsTrue(testScreen.tempCircleV.x1_circle == 120);

			//mocking input 3 for traversing in top to bottom y-direction and y cordinate updating properly
			testScreen.tempCircleV.x1_circle = 120;
			testScreen.tempCircleV.y1_circle = 40;
			testScreen.tempCircleV.traversing_count = SIDETOPBOTTOM;
			testScreen.myCircleList.push_back(testScreen.tempCircleV);
			testScreen.clickActionForMouseAndKeyboard(1);
			Assert::IsTrue(testScreen.tempCircleV.y1_circle == 120);

			//mocking input 4 for traversing in right to left in x-direction and x cordinate updating properly
			testScreen.tempCircleV.x1_circle = 120;
			testScreen.tempCircleV.y1_circle = 120;
			testScreen.tempCircleV.traversing_count = DOWNRIGHTLEFT;
			testScreen.myCircleList.push_back(testScreen.tempCircleV);
			testScreen.clickActionForMouseAndKeyboard(1);
			Assert::IsTrue(testScreen.tempCircleV.x1_circle == 40);

			//mocking input 5 for traversing in bottom to top in y-direction and y cordinate updating properly
			testScreen.tempCircleV.x1_circle = 40;
			testScreen.tempCircleV.y1_circle = 120;
			testScreen.tempCircleV.traversing_count = SIDEBOTTOMTOP;
			testScreen.myCircleList.push_back(testScreen.tempCircleV);
			testScreen.clickActionForMouseAndKeyboard(1);
			Assert::IsTrue(testScreen.tempCircleV.x1_circle == 40);

			//mocking input 6 making the circle list size is 20 and should not allow to add if max size is reached
			testScreen.myCircleList.clear();
			for (int i = 0; i < 20; i++)
			{
				testScreen.tempCircleV.x1_circle = 40;
				testScreen.tempCircleV.y1_circle = 40;
				testScreen.tempCircleV.traversing_count = SIDEBOTTOMTOP;
				testScreen.myCircleList.push_back(testScreen.tempCircleV);
			}
			testScreen.tempCircleV.x1_circle = 40;
			testScreen.tempCircleV.y1_circle = 40;
			testScreen.tempCircleV.traversing_count = SIDEBOTTOMTOP;
			testScreen.clickActionForMouseAndKeyboard(1);
			Assert::IsTrue(testScreen.myCircleList.size() == 20);

			//mocking input 7 for name == 2 to check circles are reducing from the list
			testScreen.clickActionForMouseAndKeyboard(2);
			Assert::IsTrue(testScreen.myCircleList.size() == 19);
		}
		TEST_METHOD(TestMethodtranslate)
		{
			screen testScreen;
			//**************mocking input 1
			//with 4 circles and translating in UPPLEFTRIGHT direction with value 10 and checking the output
			testScreen.tempCircleV.x1_circle = 40;
			testScreen.tempCircleV.y1_circle = 40;
			testScreen.tempCircleV.traversing_count = UPPLEFTRIGHT;
			for (int i = 0; i < 5; i++)
			{
				testScreen.clickActionForMouseAndKeyboard(1);
			}
			testScreen.translate(10);
			list<circleCordinates>::iterator ptr;
			int temp_x1_circle = 40;
			for (ptr = testScreen.myCircleList.begin(); ptr != testScreen.myCircleList.end(); ptr++)
			{
				Assert::IsTrue(ptr->x1_circle == (temp_x1_circle + 10));
				temp_x1_circle += 80;
			}

			//**************mocking input 2
			//(50,40),(130,40),(210,40),(290,40),(370,40)
			testScreen.clickActionForMouseAndKeyboard(1);
			//(50,40),(130,40),(210,40),(290,40),(370,40),(450,40)
			testScreen.translate(10);
			//(60,40),(140,40),(220,40),(300,40),(380,40),"(460,50)"
			Assert::IsTrue(testScreen.myCircleList.back().x1_circle == 460);
			Assert::IsTrue(testScreen.myCircleList.back().y1_circle == 50);
			Assert::IsTrue(testScreen.myCircleList.back().toggleTranslate == false);
			Assert::IsTrue(testScreen.myCircleList.back().traversing_count == SIDETOPBOTTOM);

			//**************mocking input 3
			for (int i = 0; i < 5; i++)
			{
				testScreen.clickActionForMouseAndKeyboard(1);
			}
			//(60,40),(140,40),(220,40),(300,40),(380,40),(460,50),(460,130),(460,210),(460,290),(460,370),(460,450)
			Assert::IsTrue(testScreen.myCircleList.back().x1_circle == 460);
			Assert::IsTrue(testScreen.myCircleList.back().y1_circle == 450);
			testScreen.translate(10);
			//(70,40),(150,40),(230,40),(310,40),(390,40),(460,60),(460,140),(460,220),(460,300),(460,380),(460,460)
			Assert::IsTrue(testScreen.myCircleList.back().x1_circle == 460);
			Assert::IsTrue(testScreen.myCircleList.back().y1_circle == 460);
			Assert::IsTrue(testScreen.myCircleList.back().toggleTranslate == true);
			Assert::IsTrue(testScreen.myCircleList.back().traversing_count == DOWNRIGHTLEFT);
			testScreen.translate(10);
			//(80,40),(160,40),(240,40),(320,40),(400,40),(460,70),(460,150),(460,230),(460,310),(460,390),(450,460)
			Assert::IsTrue(testScreen.myCircleList.back().x1_circle == 450);
			Assert::IsTrue(testScreen.myCircleList.back().y1_circle == 460);

			//**************mocking input 4
			for (int i = 0; i < 5; i++)
			{
				testScreen.clickActionForMouseAndKeyboard(1);
			}
			//(80,40),(160,40),(240,40),(320,40),(400,40),(460,60),(460,140),(460,220),(460,300),(460,380),(450,460)
			//(370,460),(290,460),(210,460),(130,460),(50,460)
			Assert::IsTrue(testScreen.myCircleList.back().x1_circle == 50);
			Assert::IsTrue(testScreen.myCircleList.back().y1_circle == 460);
			testScreen.translate(10);
			//(90,40),(170,40),(250,40),(330,40),(410,40),(460,70),(460,150),(460,230),(460,310),(460,390),(450,460)
			//(360,460),(280,460),(200,460),(120,460),(40,450)
			Assert::IsTrue(testScreen.myCircleList.back().y1_circle == 450);
			Assert::IsTrue(testScreen.myCircleList.back().x1_circle == 40);
			Assert::IsTrue(testScreen.myCircleList.back().toggleTranslate == false);
			Assert::IsTrue(testScreen.myCircleList.back().traversing_count == SIDEBOTTOMTOP);

			//**************mocking input 5
			for (int i = 0; i < 4; i++)
			{
				testScreen.clickActionForMouseAndKeyboard(1);
			}
			//(90,40),(170,40),(250,40),(330,40),(410,40),(460,70),(460,150),(460,230),(460,310),(460,390),(450,460)
			//(360,460),(280,460),(200,460),(120,460),(40,450)
			//(40,370),(40,290),(40,210),(40,130)
			Assert::IsTrue(testScreen.myCircleList.back().x1_circle == 40);
			Assert::IsTrue(testScreen.myCircleList.back().y1_circle == 130);
			Assert::IsTrue(testScreen.myCircleList.size() == 20);
			testScreen.translate(10);
			//(100,40),(180,40),(260,40),(340,40),(420,40),(460,80),(460,160),(460,240),(460,320),(460,400),(440,460)
			//(350,460),(270,460),(190,460),(110,460),(40,440)
			//(40,360),(40,280),(40,200),(40,120)
			Assert::IsTrue(testScreen.myCircleList.back().x1_circle == 40);
			Assert::IsTrue(testScreen.myCircleList.back().y1_circle == 120);
		}
		TEST_METHOD(TestMethodColortheCube)
		{
			buttonCube* myCube = buttonCube::getinstance();
			myCube->colortheCube();
			Assert::IsTrue(myCube->color1 != NULL &&
				myCube->color2 != NULL &&
				myCube->color3 != NULL &&
				myCube->color4 != NULL &&
				myCube->color5 != NULL &&
				myCube->color6 != NULL);
		}
		TEST_METHOD(TestMethoddisabletheCube)
		{
			buttonCube* myCube = buttonCube::getinstance();
			myCube->disabletheCube();
			Assert::IsTrue(myCube->color1 != NULL &&
				myCube->color2 != NULL &&
				myCube->color3 != NULL &&
				myCube->color4 != NULL &&
				myCube->color5 != NULL &&
				myCube->color6 != NULL);
		}
	};
}