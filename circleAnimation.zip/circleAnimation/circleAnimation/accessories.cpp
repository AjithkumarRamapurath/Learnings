#include "accessories.h"
//------------------------------------------------------------------------------------------------------------------//
void buttonCube::setCubeVertices(int _offset)
{
	buttonCube* myCube = buttonCube::getinstance();
	//back face
	myCube->vertex11[0] = _offset + 0;   myCube->vertex11[1] = UPPYVALUE; myCube->vertex11[2] = 1;
	myCube->vertex12[0] = _offset + 100; myCube->vertex12[1] = UPPYVALUE; myCube->vertex12[2] = 1;
	myCube->vertex13[0] = _offset + 100; myCube->vertex13[1] = DOWNYVALUE; myCube->vertex13[2] = 1;
	myCube->vertex14[0] = _offset + 0;   myCube->vertex14[1] = DOWNYVALUE; myCube->vertex14[2] = 1;
	//upper face
	myCube->vertex21[0] = _offset + 0;   myCube->vertex21[1] = UPPYVALUE; myCube->vertex21[2] = 1;
	myCube->vertex22[0] = _offset + 100; myCube->vertex22[1] = UPPYVALUE; myCube->vertex22[2] = 1;
	myCube->vertex23[0] = _offset + 100; myCube->vertex23[1] = UPPYVALUE; myCube->vertex23[2] = -1;
	myCube->vertex24[0] = _offset + 0;   myCube->vertex24[1] = UPPYVALUE; myCube->vertex24[2] = -1;
	//front face
	myCube->vertex31[0] = _offset + 0;   myCube->vertex31[1] = UPPYVALUE; myCube->vertex31[2] = -1;
	myCube->vertex32[0] = _offset + 100; myCube->vertex32[1] = UPPYVALUE; myCube->vertex32[2] = -1;
	myCube->vertex33[0] = _offset + 100; myCube->vertex33[1] = DOWNYVALUE; myCube->vertex33[2] = -1;
	myCube->vertex34[0] = _offset + 0;   myCube->vertex34[1] = DOWNYVALUE; myCube->vertex34[2] = -1;
	//rigt face
	myCube->vertex41[0] = _offset + 100;  myCube->vertex41[1] = UPPYVALUE; myCube->vertex41[2] = -1;
	myCube->vertex42[0] = _offset + 100;  myCube->vertex42[1] = UPPYVALUE; myCube->vertex42[2] = 1;
	myCube->vertex43[0] = _offset + 100;  myCube->vertex43[1] = DOWNYVALUE; myCube->vertex43[2] = 1;
	myCube->vertex44[0] = _offset + 100;  myCube->vertex44[1] = DOWNYVALUE; myCube->vertex44[2] = -1;
	//lower face
	myCube->vertex51[0] = _offset + 0;    myCube->vertex51[1] = DOWNYVALUE; myCube->vertex51[2] = -1;
	myCube->vertex52[0] = _offset + 100;  myCube->vertex52[1] = DOWNYVALUE; myCube->vertex52[2] = -1;
	myCube->vertex53[0] = _offset + 100;  myCube->vertex53[1] = DOWNYVALUE; myCube->vertex53[2] = 1;
	myCube->vertex54[0] = _offset + 0;    myCube->vertex54[1] = DOWNYVALUE; myCube->vertex54[2] = -1;
	//left face
	myCube->vertex61[0] = _offset + 0;  myCube->vertex61[1] = UPPYVALUE; myCube->vertex61[2] = -1;
	myCube->vertex62[0] = _offset + 0;  myCube->vertex62[1] = UPPYVALUE; myCube->vertex62[2] = 1;
	myCube->vertex63[0] = _offset + 0;  myCube->vertex63[1] = DOWNYVALUE; myCube->vertex63[2] = 1;
	myCube->vertex64[0] = _offset + 0;  myCube->vertex64[1] = DOWNYVALUE; myCube->vertex64[2] = -1;
}
//------------------------------------------------------------------------------------------------------------------//
void buttonCube::disabletheCube()
{
	buttonCube* myCube = buttonCube::getinstance();
	myCube->color1[0] = 0.1; myCube->color1[1] = 0.1; myCube->color1[2] = 0.1;
	myCube->color2[0] = 0.2; myCube->color2[1] = 0.2; myCube->color2[2] = 0.2;
	myCube->color3[0] = 0.3; myCube->color3[1] = 0.3; myCube->color3[2] = 0.3;
	myCube->color4[0] = 0.4; myCube->color4[1] = 0.4; myCube->color4[2] = 0.4;
	myCube->color5[0] = 0.5; myCube->color5[1] = 0.5; myCube->color5[2] = 0.5;
	myCube->color6[0] = 0.4; myCube->color6[1] = 0.4; myCube->color6[2] = 0.4;
}
//------------------------------------------------------------------------------------------------------------------//
void buttonCube::colortheCube()
{
	buttonCube* myCube = buttonCube::getinstance();
	myCube->color1[0] = 1.0; myCube->color1[1] = 0.0; myCube->color1[2] = 0.0;//red
	myCube->color2[0] = 0.0; myCube->color2[1] = 1.0; myCube->color2[2] = 0.0;//green
	myCube->color3[0] = 0.0; myCube->color3[1] = 0.0; myCube->color3[2] = 1.0;//blue
	myCube->color4[0] = 1.0; myCube->color4[1] = 1.0; myCube->color4[2] = 0.0;//yellow
	myCube->color5[0] = 1.0; myCube->color5[1] = 0.0; myCube->color5[2] = 1.0;//purple
	myCube->color6[0] = 1.0; myCube->color6[1] = 1.0; myCube->color6[2] = 0.0;//yellow
}
//------------------------------------------------------------------------------------------------------------------//
circleCordinates::circleCordinates()
{
	x1_circle = 40;//Initialisation of circle position on the screen for x-cordinate
	y1_circle = 40;//Initialisation of circle position on the screen for y-cordinate
	traversing_count = 0;//Initialising the traversing count
	toggleTranslate = true;//setting initial translation from left to right
}
//------------------------------------------------------------------------------------------------------------------//
//This method renders cubes to hold '+' and '-' buttons
void screen::renderbuttonCubeOntheScreen()
{
	buttonCube* myCube = buttonCube::getinstance();
	int _offset = 120;
	GLint cubeCount = 0;
	while (cubeCount < 2)
	{
		cubeCount++;
		glLoadName(cubeCount);
		if (cubeCount == 1)
		{
			if (myCircleList.size() == MAXCIRCLES)
			{
				myCube->disabletheCube();
			}
			else
			{
				myCube->colortheCube();
			}
		}
		else if (cubeCount == 2)
		{
			if (myCircleList.size() == 0)
			{
				myCube->disabletheCube();
			}
			else
			{
				myCube->colortheCube();
			}
		}
		myCube->setCubeVertices(_offset);
		glBegin(GL_QUADS);
		glColor3fv(myCube->color1);
		glVertex3fv(myCube->vertex11);
		glVertex3fv(myCube->vertex12);
		glVertex3fv(myCube->vertex13);
		glVertex3fv(myCube->vertex14);

		glColor3fv(myCube->color2);
		glVertex3fv(myCube->vertex21);
		glVertex3fv(myCube->vertex22);
		glVertex3fv(myCube->vertex23);
		glVertex3fv(myCube->vertex24);

		glColor3fv(myCube->color3);
		glVertex3fv(myCube->vertex31);
		glVertex3fv(myCube->vertex32);
		glVertex3fv(myCube->vertex33);
		glVertex3fv(myCube->vertex34);

		glColor3fv(myCube->color4);
		glVertex3fv(myCube->vertex41);
		glVertex3fv(myCube->vertex42);
		glVertex3fv(myCube->vertex43);
		glVertex3fv(myCube->vertex44);

		glColor3fv(myCube->color5);
		glVertex3fv(myCube->vertex51);
		glVertex3fv(myCube->vertex52);
		glVertex3fv(myCube->vertex53);
		glVertex3fv(myCube->vertex54);

		glColor3fv(myCube->color6);
		glVertex3fv(myCube->vertex61);
		glVertex3fv(myCube->vertex62);
		glVertex3fv(myCube->vertex63);
		glVertex3fv(myCube->vertex64);
		glEnd();
		_offset = 280;
	}
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This method renders lines which will get converted to '+' and '-' symbols
void screen::renderLineOntheScreen()
{
	glBegin(GL_LINES);
	glColor3f(0.0, 0.0, 0.0);
	glVertex3f(150, 325, -1);
	glVertex3f(190, 325, -1);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0.0, 0.0, 0.0);
	glVertex3f(170, 310, -1);
	glVertex3f(170, 340, -1);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0.0, 0.0, 0.0);
	glVertex3f(320, 325, -1);
	glVertex3f(340, 325, -1);
	glEnd();
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This method renders a circle while co-ordinates are received
void screen::renderCirclesOntheScreen(float x1_circle, float y1_circle)
{
	float  x2, y2;
	float angle;
	double radius = RADIUS;
	glColor3ub(rand() % 255, rand() % 255, rand() % 255);
	glBegin(GL_TRIANGLE_FAN);
	glVertex3f(x1_circle, y1_circle, -1);
	for (angle = 1.0f; angle<361.0f; angle += 0.1)
	{
		x2 = x1_circle + sin(angle)*radius;
		y2 = y1_circle + cos(angle)*radius;
		glVertex3f(x2, y2, -1);
	}
	glEnd();
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//This method will process the mouse clicks based on the name value given during glRenderMode == GL_SELECT 
//This also get invoked by arrow key events with names value hardcoded
void screen::clickActionForMouseAndKeyboard(GLuint names)
{
	if (names == 1)
	{
		if (myCircleList.size() == 0)
		{
			myCircleList.push_back(tempCircleV);
		}
		else
		{
			tempCircleV = myCircleList.back();
			if (tempCircleV.traversing_count == UPPLEFTRIGHT)
			{
				tempCircleV.x1_circle = tempCircleV.x1_circle + 2 * RADIUS;
			}
			else if (tempCircleV.traversing_count == SIDETOPBOTTOM)
			{
				tempCircleV.y1_circle = tempCircleV.y1_circle + 2 * RADIUS;
			}
			else if (tempCircleV.traversing_count == DOWNRIGHTLEFT)
			{
				tempCircleV.x1_circle = tempCircleV.x1_circle - 2 * RADIUS;
			}
			else if (tempCircleV.traversing_count == SIDEBOTTOMTOP)
			{
				tempCircleV.y1_circle = tempCircleV.y1_circle - 2 * RADIUS;
			}
			//This logic is added for limiting max 20 circles to the screen
			if (myCircleList.size() < MAXCIRCLES)
			{
				myCircleList.push_back(tempCircleV);
			}
		}
	}
	else if (names == 2)
	{
		if (myCircleList.size() > 0)
			myCircleList.pop_back();
	}
}
//------------------------------------------------------------------------------------------------------------------//

//------------------------------------------------------------------------------------------------------------------//
//this method will translate circle list by translate value amount in x/y direction depending on the logic
void screen::translate(int translatevalue)
{
	list<circleCordinates>::iterator ptr;
	for (ptr = myCircleList.begin(); ptr != myCircleList.end(); ptr++)
	{
		if (ptr->toggleTranslate)
		{
			if (ptr->traversing_count == DOWNRIGHTLEFT)
			{
				ptr->x1_circle -= translatevalue;
				if (ptr->x1_circle < OrthoMIN)
				{
					ptr->toggleTranslate = false;
					ptr->traversing_count = SIDEBOTTOMTOP;
				}
			}
			else if(ptr->traversing_count == UPPLEFTRIGHT)
			{
				ptr->x1_circle += translatevalue;
				if (ptr->x1_circle > OrthoMAX)
				{
					ptr->toggleTranslate = false;
					ptr->traversing_count = SIDETOPBOTTOM;
				}
			}
		}
		if (!ptr->toggleTranslate)
		{
			if (ptr->traversing_count == SIDEBOTTOMTOP)
			{
				ptr->y1_circle -= translatevalue;
				if (ptr->y1_circle< OrthoMIN)
				{
					ptr->toggleTranslate = true;
					ptr->traversing_count = UPPLEFTRIGHT;
				}
			}
			else if(ptr->traversing_count == SIDETOPBOTTOM)
			{
				ptr->y1_circle += translatevalue;
				if (ptr->y1_circle > OrthoMAX)
				{
					ptr->toggleTranslate = true;
					ptr->traversing_count = DOWNRIGHTLEFT;
				}
			}
		}
	}
}
//------------------------------------------------------------------------------------------------------------------//

